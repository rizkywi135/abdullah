
import React from 'react';
import { GeneratedLogo } from '../types';

interface LogoCardProps {
  logo: GeneratedLogo;
  isSelected: boolean;
  onClick: () => void;
}

const LogoCard: React.FC<LogoCardProps> = ({ logo, isSelected, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={`relative cursor-pointer group rounded-xl overflow-hidden border-2 transition-all duration-200 ${
        isSelected ? 'border-blue-600 ring-2 ring-blue-100' : 'border-transparent hover:border-slate-200'
      }`}
    >
      <img 
        src={logo.url} 
        alt={logo.prompt} 
        className="w-full h-auto aspect-square object-cover"
      />
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <span className="text-white text-xs font-medium px-2 py-1 bg-black/60 rounded backdrop-blur-sm">Lihat Detail</span>
      </div>
    </div>
  );
};

export default LogoCard;
