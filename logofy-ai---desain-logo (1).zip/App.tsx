
import React, { useState } from 'react';
import { LogoConfig, LogoStyle, GeneratedLogo } from './types';
import { geminiService } from './services/geminiService';
import LogoCard from './components/LogoCard';

const App: React.FC = () => {
  const [config, setConfig] = useState<LogoConfig>({
    brandName: '',
    slogan: '',
    style: LogoStyle.MINIMALIST,
    colorType: 'solid',
    primaryColor: '#3b82f6',
    secondaryColor: '#1d4ed8',
    description: ''
  });

  const [isCustomStyle, setIsCustomStyle] = useState(false);
  const [customStyleText, setCustomStyleText] = useState('');
  const [history, setHistory] = useState<GeneratedLogo[]>([]);
  const [currentLogo, setCurrentLogo] = useState<GeneratedLogo | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [refineText, setRefineText] = useState('');
  const [isRefining, setIsRefining] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getStyleIcon = (style: string) => {
    switch (style) {
      case LogoStyle.MINIMALIST: return 'fa-minus';
      case LogoStyle.MODERN: return 'fa-bolt';
      case LogoStyle.VINTAGE: return 'fa-clock-rotate-left';
      case LogoStyle.GEOMETRIC: return 'fa-shapes';
      case LogoStyle.ABSTRACT: return 'fa-cloud';
      case LogoStyle.LUXURY: return 'fa-crown';
      case LogoStyle.PLAYFUL: return 'fa-face-smile';
      case LogoStyle.TECH: return 'fa-microchip';
      default: return 'fa-wand-magic-sparkles';
    }
  };

  const getStyleTheme = (style: string) => {
    switch (style) {
      case LogoStyle.TECH: return { bg: 'bg-slate-900', decoration: 'border-cyan-500/20 shadow-cyan-500/10', text: 'text-white' };
      case LogoStyle.LUXURY: return { bg: 'bg-stone-900', decoration: 'border-amber-500/30 shadow-amber-500/10', text: 'text-white' };
      case LogoStyle.PLAYFUL: return { bg: 'bg-rose-50', decoration: 'border-rose-200', text: 'text-slate-900' };
      case LogoStyle.MINIMALIST: return { bg: 'bg-white', decoration: 'border-slate-100', text: 'text-slate-900' };
      case LogoStyle.VINTAGE: return { bg: 'bg-orange-50/30', decoration: 'border-orange-200/50', text: 'text-slate-900' };
      default: return { bg: 'bg-slate-50', decoration: 'border-slate-200', text: 'text-slate-900' };
    }
  };

  const handleStyleSelect = (style: string) => {
    setIsCustomStyle(false);
    setConfig({ ...config, style });
  };

  const handleCustomStyleToggle = () => {
    setIsCustomStyle(true);
    setConfig({ ...config, style: customStyleText || 'Kustom' });
  };

  const handleCustomStyleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setCustomStyleText(val);
    if (isCustomStyle) {
      setConfig({ ...config, style: val || 'Kustom' });
    }
  };

  const handleGenerate = async () => {
    if (!config.brandName || !config.description) {
      setError("Mohon isi setidaknya Nama Brand dan Deskripsi.");
      return;
    }

    setError(null);
    setIsGenerating(true);
    try {
      const selectedStyle = isCustomStyle ? (customStyleText || 'Kustom') : config.style;
      const colorDescription = config.colorType === 'gradient' 
        ? `Gradient from ${config.primaryColor} to ${config.secondaryColor}`
        : `Solid color ${config.primaryColor}`;
        
      const fullPrompt = `Brand: ${config.brandName}. Slogan: ${config.slogan}. Description: ${config.description}. Color Scheme: ${colorDescription}.`;
      const imageUrl = await geminiService.generateLogo(fullPrompt, selectedStyle);
      
      const newLogo: GeneratedLogo = {
        id: Math.random().toString(36).substr(2, 9),
        url: imageUrl,
        prompt: fullPrompt,
        style: selectedStyle,
        createdAt: new Date()
      };

      setHistory(prev => [newLogo, ...prev]);
      setCurrentLogo(newLogo);
    } catch (err) {
      setError("Gagal membuat logo. Silakan coba lagi.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRefine = async () => {
    if (!currentLogo || !refineText) return;

    setError(null);
    setIsRefining(true);
    try {
      const refinedUrl = await geminiService.refineLogo(currentLogo.url, refineText);
      const newLogo: GeneratedLogo = {
        id: Math.random().toString(36).substr(2, 9),
        url: refinedUrl,
        prompt: `Refined: ${refineText}`,
        style: currentLogo.style,
        createdAt: new Date()
      };

      setHistory(prev => [newLogo, ...prev]);
      setCurrentLogo(newLogo);
      setRefineText('');
    } catch (err) {
      setError("Gagal memperbarui logo. Silakan coba lagi.");
    } finally {
      setIsRefining(false);
    }
  };

  const handleDownload = (logoToDownload: GeneratedLogo | null) => {
    if (!logoToDownload) return;
    const link = document.createElement('a');
    link.href = logoToDownload.url;
    link.download = `${config.brandName || 'logo'}-${logoToDownload.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadAll = () => {
    if (history.length === 0) return;
    history.forEach((logo, index) => {
      setTimeout(() => {
        const link = document.createElement('a');
        link.href = logo.url;
        link.download = `${config.brandName || 'logo'}-riwayat-${index + 1}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }, index * 200);
    });
  };

  const currentTheme = getStyleTheme(config.style);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 text-slate-900">
      {/* Sidebar - Configuration */}
      <aside className="w-80 bg-white border-r border-slate-200 overflow-y-auto custom-scrollbar flex flex-col z-20 shadow-xl">
        <div className="p-6 border-b border-slate-100 bg-white sticky top-0 z-10">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
              <i className="fa-solid fa-wand-magic-sparkles"></i>
            </div>
            <h1 className="text-xl font-bold font-outfit text-slate-900">Logofy AI</h1>
          </div>
          <p className="text-xs text-slate-500">Kecerdasan Buatan untuk Brand Anda</p>
        </div>

        <div className="p-6 space-y-6 flex-1">
          {/* Real-time Identity Preview Card */}
          <div className={`rounded-2xl p-5 shadow-2xl overflow-hidden relative transition-all duration-500 border-2 ${currentTheme.bg} ${currentTheme.decoration} group`}>
            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
              <i className={`fa-solid ${getStyleIcon(config.style)} text-5xl`}></i>
            </div>
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-full flex justify-between items-center mb-4">
                 <p className={`text-[10px] font-bold uppercase tracking-widest opacity-40 ${currentTheme.text}`}>Live Identity</p>
                 <div className="flex gap-1.5">
                   <div className="w-2 h-2 rounded-full shadow-sm" style={{ backgroundColor: config.primaryColor }}></div>
                   {config.colorType === 'gradient' && <div className="w-2 h-2 rounded-full shadow-sm" style={{ backgroundColor: config.secondaryColor }}></div>}
                 </div>
              </div>
              
              <div 
                className="w-24 h-24 rounded-3xl bg-white flex items-center justify-center shadow-xl transition-all duration-500 relative overflow-hidden border p-4"
                style={{ 
                  boxShadow: `0 15px 35px -5px ${config.primaryColor}30`,
                  borderColor: config.colorType === 'solid' ? `${config.primaryColor}30` : 'transparent'
                }}
              >
                {/* Style Pattern Overlay */}
                {config.style === LogoStyle.TECH && <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:8px_8px]"></div>}
                {config.style === LogoStyle.GEOMETRIC && <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[linear-gradient(45deg,#000_25%,transparent_25%,transparent_50%,#000_50%,#000_75%,transparent_75%,transparent)] [background-size:12px_12px]"></div>}
                
                {/* Logo Image or Icon Placeholder */}
                {currentLogo ? (
                  <img src={currentLogo.url} className="w-full h-full object-contain relative z-10" alt="Logo" />
                ) : (
                  <i className={`fa-solid ${getStyleIcon(config.style)} text-4xl transition-colors duration-500 z-10`} style={{ color: config.primaryColor }}></i>
                )}
                
                {/* Color/Gradient Overlay */}
                <div 
                  className="absolute inset-0 opacity-10 pointer-events-none z-0"
                  style={{ 
                    background: config.colorType === 'solid' 
                      ? config.primaryColor 
                      : `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})` 
                  }}
                ></div>
              </div>

              <div className="mt-4 text-center w-full">
                <h4 className={`font-outfit font-bold text-sm truncate px-2 transition-colors ${currentTheme.text}`}>
                  {config.brandName || "Nama Brand"}
                </h4>
                <p className={`text-[10px] italic truncate px-4 opacity-60 ${currentTheme.text}`}>
                  {config.slogan || "Slogan Brand Anda"}
                </p>
                <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 rounded-full text-[9px] font-bold border border-white/10 backdrop-blur-sm">
                  <i className={`fa-solid ${getStyleIcon(config.style)}`}></i>
                  <span className="uppercase tracking-widest">{config.style}</span>
                </div>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Nama Brand</label>
            <input 
              type="text" 
              placeholder="Contoh: Acme Studio"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm transition-all"
              value={config.brandName}
              onChange={e => setConfig({...config, brandName: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Slogan</label>
            <input 
              type="text" 
              placeholder="Contoh: Solusi Masa Depan"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm transition-all"
              value={config.slogan}
              onChange={e => setConfig({...config, slogan: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Gaya Visual</label>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {Object.values(LogoStyle).map(style => (
                <button
                  key={style}
                  onClick={() => handleStyleSelect(style)}
                  className={`px-3 py-2 text-[10px] font-bold uppercase tracking-tighter rounded-xl border transition-all flex items-center justify-center gap-2 ${
                    !isCustomStyle && config.style === style 
                    ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-600/20' 
                    : 'bg-white border-slate-200 text-slate-500 hover:border-blue-200 hover:text-blue-600'
                  }`}
                >
                  <i className={`fa-solid ${getStyleIcon(style)} opacity-70`}></i>
                  {style}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Warna Utama</label>
            <div className="space-y-4">
              <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 shadow-inner">
                <button 
                  onClick={() => setConfig({...config, colorType: 'solid'})}
                  className={`flex-1 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${config.colorType === 'solid' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                >
                  Solid
                </button>
                <button 
                  onClick={() => setConfig({...config, colorType: 'gradient'})}
                  className={`flex-1 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${config.colorType === 'gradient' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                >
                  Gradien
                </button>
              </div>

              <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="flex-1 flex flex-col gap-1.5">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{config.colorType === 'gradient' ? 'Warna A' : 'Pilih Warna'}</span>
                  <div className="flex items-center gap-3">
                    <input 
                      type="color" 
                      className="w-10 h-10 rounded-xl cursor-pointer border-2 border-white shadow-sm"
                      value={config.primaryColor}
                      onChange={e => setConfig({...config, primaryColor: e.target.value})}
                    />
                    <span className="text-xs font-mono text-slate-500">{config.primaryColor.toUpperCase()}</span>
                  </div>
                </div>

                {config.colorType === 'gradient' && (
                  <>
                    <div className="text-slate-300">
                      <i className="fa-solid fa-arrow-right-long"></i>
                    </div>
                    <div className="flex-1 flex flex-col gap-1.5">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Warna B</span>
                      <div className="flex items-center gap-3">
                        <input 
                          type="color" 
                          className="w-10 h-10 rounded-xl cursor-pointer border-2 border-white shadow-sm"
                          value={config.secondaryColor}
                          onChange={e => setConfig({...config, secondaryColor: e.target.value})}
                        />
                        <span className="text-xs font-mono text-slate-500">{config.secondaryColor.toUpperCase()}</span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Deskripsi Detail</label>
            <textarea 
              rows={3}
              placeholder="Jelaskan elemen spesifik (misal: singa abstrak, gunung minimalis)..."
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm resize-none transition-all"
              value={config.description}
              onChange={e => setConfig({...config, description: e.target.value})}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-100 rounded-xl flex items-start gap-2 animate-shake">
              <i className="fa-solid fa-triangle-exclamation text-red-500 mt-0.5"></i>
              <span className="text-xs text-red-600 font-medium leading-tight">{error}</span>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-4 rounded-2xl font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 transition-all ${
              isGenerating 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
              : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xl shadow-blue-600/30 active:scale-[0.98]'
            }`}
          >
            {isGenerating ? (
              <>
                <i className="fa-solid fa-circle-notch fa-spin"></i>
                <span>Membuat...</span>
              </>
            ) : (
              <>
                <i className="fa-solid fa-wand-sparkles"></i>
                <span>Generasi Logo</span>
              </>
            )}
          </button>
        </div>
      </aside>

      {/* Main Canvas Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden bg-[#f3f4f6]">
        {/* Top Header */}
        <header className="h-16 bg-white/80 backdrop-blur-xl border-b border-slate-200 flex items-center justify-between px-8 z-10 sticky top-0 shadow-sm">
          <div className="flex items-center gap-4">
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-widest">Kanvas Studio</h2>
            {currentLogo && <div className="h-4 w-px bg-slate-300"></div>}
            {currentLogo && <span className="text-xs text-slate-400 font-medium">Aktif: {new Date(currentLogo.createdAt).toLocaleTimeString()}</span>}
          </div>
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => handleDownload(currentLogo)}
              disabled={!currentLogo}
              className="px-5 py-2 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-black disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-lg flex items-center gap-2"
            >
              <i className="fa-solid fa-cloud-arrow-down"></i>
              Unduh Hasil
            </button>
          </div>
        </header>

        {/* Content Studio Area */}
        <div className="flex-1 overflow-hidden p-12 flex items-center justify-center">
          {isGenerating ? (
            <div className="flex flex-col items-center gap-6 text-center animate-pulse">
              <div className="relative">
                <div className="w-24 h-24 border-8 border-blue-600/10 rounded-full"></div>
                <div className="w-24 h-24 border-8 border-blue-600 rounded-full border-t-transparent absolute top-0 animate-spin"></div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800">Menyusun Brand Identity Anda</h3>
                <p className="text-sm text-slate-500 mt-1">Seni digital sedang diracik oleh algoritma Gemini...</p>
              </div>
            </div>
          ) : currentLogo ? (
            <div className="relative group max-w-2xl w-full perspective-1000">
              <div className="absolute -inset-4 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-[3rem] blur-2xl opacity-10 group-hover:opacity-20 transition-opacity"></div>
              <div className="relative bg-white p-8 rounded-[2.5rem] shadow-2xl overflow-hidden aspect-square flex items-center justify-center border-8 border-white group-hover:rotate-1 transition-transform duration-500">
                <img 
                  src={currentLogo.url} 
                  alt="Final Logo Design" 
                  className="max-w-full max-h-full w-full h-full object-contain drop-shadow-2xl"
                />
              </div>
            </div>
          ) : (
            <div className="max-w-md text-center">
              <div className="w-24 h-24 bg-white shadow-xl text-blue-600 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-4xl rotate-3">
                <i className="fa-solid fa-palette"></i>
              </div>
              <h3 className="text-3xl font-bold font-outfit text-slate-900 mb-4">Mulai Perjalanan Kreatif</h3>
              <p className="text-slate-500 text-base leading-relaxed font-medium">
                Gunakan panel samping untuk mendefinisikan visi brand Anda. AI kami akan memproses deskripsi Anda menjadi aset visual profesional.
              </p>
            </div>
          )}
        </div>

        {/* Refinement Bottom Bar */}
        {currentLogo && (
          <div className="p-8 bg-white/60 backdrop-blur-md border-t border-slate-200 shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center gap-4 p-2 bg-white border border-slate-200 rounded-3xl shadow-inner">
                <div className="flex-1 px-4">
                  <input 
                    type="text" 
                    placeholder="Contoh: 'Buat garis lebih tebal' atau 'Tambahkan efek kilau emas'..."
                    className="w-full bg-transparent border-none focus:outline-none text-sm font-medium py-2"
                    value={refineText}
                    onChange={e => setRefineText(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleRefine()}
                  />
                </div>
                <button
                  onClick={handleRefine}
                  disabled={isRefining || !refineText}
                  className={`px-8 py-3 rounded-2xl font-bold uppercase tracking-widest text-xs transition-all flex items-center gap-3 ${
                    isRefining || !refineText 
                    ? 'bg-slate-100 text-slate-400' 
                    : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg'
                  }`}
                >
                  {isRefining ? (
                    <i className="fa-solid fa-spinner fa-spin"></i>
                  ) : (
                    <i className="fa-solid fa-wand-magic-sparkles"></i>
                  )}
                  <span>Sempurnakan</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Right Sidebar - Library & History */}
      <aside className="w-72 bg-white border-l border-slate-200 flex flex-col z-20">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-[0.2em]">Koleksi</h2>
            <p className="text-[10px] text-slate-400 font-medium">Library Desain Anda</p>
          </div>
          {history.length > 0 && (
            <span className="px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-lg">{history.length}</span>
          )}
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-5 custom-scrollbar bg-slate-50/30">
          {history.length > 0 ? (
            <>
              {history.map(logo => (
                <LogoCard 
                  key={logo.id} 
                  logo={logo} 
                  isSelected={currentLogo?.id === logo.id}
                  onClick={() => setCurrentLogo(logo)}
                />
              ))}
              <div className="pt-4">
                <button
                  onClick={handleDownloadAll}
                  className="w-full py-3 bg-white hover:bg-slate-50 text-slate-700 text-[10px] font-bold uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 border border-slate-200 transition-all shadow-sm active:scale-[0.97]"
                >
                  <i className="fa-solid fa-box-archive"></i>
                  Eksport Semua
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full opacity-30 text-center px-4">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                <i className="fa-solid fa-clock-rotate-left text-2xl text-slate-300"></i>
              </div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-loose">Antrian Kosong</p>
            </div>
          )}
        </div>

        <div className="p-6 bg-slate-900 text-white rounded-t-[2.5rem] mt-auto">
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 shadow-lg">
            <div className="flex items-center gap-2 mb-2">
              <i className="fa-solid fa-lightbulb text-amber-400 text-xs"></i>
              <p className="text-[10px] font-bold uppercase tracking-tighter text-blue-400">Tips Optimasi</p>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed italic font-medium">
              "Gunakan kontras tinggi jika Anda memilih gradien agar logo tetap terbaca di berbagai ukuran media."
            </p>
          </div>
        </div>
      </aside>
    </div>
  );
};

export default App;
