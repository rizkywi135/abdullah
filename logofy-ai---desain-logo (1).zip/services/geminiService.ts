
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: API_KEY! });
  }

  async generateLogo(prompt: string, style: string): Promise<string> {
    const enhancedPrompt = `Create a professional logo design for a brand. 
    Style: ${style}. 
    Details: ${prompt}. 
    The logo should be high quality, vector style, centered on a clean background. 
    Avoid cluttered backgrounds or photorealistic textures unless specified. 
    Professional brand identity aesthetic.`;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: enhancedPrompt }]
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1"
          }
        }
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      throw new Error("No image data found in response");
    } catch (error) {
      console.error("Logo generation failed:", error);
      throw error;
    }
  }

  async refineLogo(base64Image: string, instruction: string): Promise<string> {
    const mimeType = 'image/png';
    const imageData = base64Image.split(',')[1];

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: imageData,
                mimeType: mimeType
              }
            },
            {
              text: `Modify this logo based on the following instruction: ${instruction}. Keep the core branding elements but apply the requested changes carefully to maintain professional quality.`
            }
          ]
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1"
          }
        }
      });

      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      throw new Error("No refinement image data found");
    } catch (error) {
      console.error("Logo refinement failed:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
