
export interface GeneratedLogo {
  id: string;
  url: string;
  prompt: string;
  style: string;
  createdAt: Date;
}

export enum LogoStyle {
  MINIMALIST = 'Minimalis',
  MODERN = 'Modern',
  VINTAGE = 'Vintage',
  GEOMETRIC = 'Geometris',
  ABSTRACT = 'Abstrak',
  LUXURY = 'Mewah',
  PLAYFUL = 'Ceria',
  TECH = 'Teknologi'
}

export type ColorType = 'solid' | 'gradient';

export interface LogoConfig {
  brandName: string;
  slogan: string;
  style: string;
  colorType: ColorType;
  primaryColor: string;
  secondaryColor: string;
  description: string;
}
